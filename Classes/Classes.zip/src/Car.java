public class Car {
    // thuộc tính
    String name;
    String brand;
    int year;

    // phương thức
    void start(){
        System.out.println("car is starting");
    }

    void stop(){
        System.out.println("car is stopping");
    }
}
