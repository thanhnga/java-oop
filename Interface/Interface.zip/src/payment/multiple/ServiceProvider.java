package payment.multiple;

public interface ServiceProvider {
    String getProviderName(); // Lấy tên nhà cung cấp
}
