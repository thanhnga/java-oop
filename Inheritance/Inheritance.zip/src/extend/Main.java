package extend;

public class Main {
    public static void main(String[] args) {
        SubClass subClass = new SubClass();
        subClass.age = 40;
        subClass.name = "Nga";
        subClass.display();
    }
}
