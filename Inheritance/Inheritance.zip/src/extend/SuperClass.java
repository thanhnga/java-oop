package extend;

public class SuperClass {
    String name;
    int age;

    void display(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}
