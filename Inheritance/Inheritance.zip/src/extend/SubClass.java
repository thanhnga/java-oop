package extend;

public class SubClass extends SuperClass {
}
