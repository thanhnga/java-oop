package overridekeyword;

public class SuperClass {
    void display() {
        System.out.println("Hello SuperClass");
    }
}
