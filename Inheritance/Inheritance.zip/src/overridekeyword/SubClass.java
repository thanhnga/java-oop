package overridekeyword;

public class SubClass extends SuperClass {
    @Override
    void display() {
        System.out.println("Hello SubClass");
    }
}
