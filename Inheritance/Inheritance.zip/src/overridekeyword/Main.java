package overridekeyword;


public class Main {

    public static void main(String[] args) {
        SubClass subClass   = new SubClass();
        subClass.display();

//        SuperClass subClass = new SubClass();
//        subClass.display();
    }
}
