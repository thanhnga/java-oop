package superkeyword;

public class Main {

    public static void main(String[] args) {
       SubClass subClass = new SubClass();
       subClass.print();
    }
}
