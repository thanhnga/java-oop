package override;

public class Cat extends Animal {
    @Override
    void sound() {
        System.out.println("Cat meows");
    }

}
