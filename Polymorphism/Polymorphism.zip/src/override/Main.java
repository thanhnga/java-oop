package override;

public class Main {
    public static void main(String[] args) {

        Animal animal1 = new Mouse();
        animal1.sound();

        Animal animal2 = new Cat();
        animal2.sound();

    }
}
