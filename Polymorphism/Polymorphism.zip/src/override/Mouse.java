package override;

public class Mouse extends Animal {

    @Override
    void sound() {
        System.out.println("Mouse squeaks");
    }

}
